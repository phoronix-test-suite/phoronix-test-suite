<?php

// Version Information

define("PTS_VERSION", "0.5.1");
define("PTS_CODENAME", "TRONDHEIM");
define("PTS_TYPE", "DESKTOP");

?>
