#!/bin/sh

cd $1
rm -f output.wav
