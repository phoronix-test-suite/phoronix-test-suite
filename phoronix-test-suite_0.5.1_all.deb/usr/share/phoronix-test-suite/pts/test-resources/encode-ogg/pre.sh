#!/bin/sh

cd $1
rm -f audio.ogg

