#!/bin/sh

cd $1
rm -f trondheim-wav-sample.flac
