#!/bin/sh

cd $1
cat ../pts-shared/trondheim-wav-sample.wav > /dev/null
