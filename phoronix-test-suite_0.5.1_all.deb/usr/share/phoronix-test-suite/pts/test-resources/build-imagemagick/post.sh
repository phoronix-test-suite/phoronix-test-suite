#!/bin/sh

cd $1
rm -rf ImageMagick-6.4.0/

