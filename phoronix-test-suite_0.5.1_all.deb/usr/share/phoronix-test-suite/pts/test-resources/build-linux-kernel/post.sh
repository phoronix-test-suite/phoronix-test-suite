#!/bin/sh

cd $1
rm -rf linux-2.6.25/
