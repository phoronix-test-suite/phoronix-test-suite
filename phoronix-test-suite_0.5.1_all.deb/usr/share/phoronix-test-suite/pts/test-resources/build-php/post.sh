#!/bin/sh

cd $1
rm -rf php-5.2.5/
