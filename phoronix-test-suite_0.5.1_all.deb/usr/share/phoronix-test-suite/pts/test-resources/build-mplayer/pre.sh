#!/bin/sh

cd $1
rm -rf MPlayer-1.0rc2/
